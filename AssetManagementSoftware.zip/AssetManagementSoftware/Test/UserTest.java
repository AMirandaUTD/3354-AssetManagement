import static org.junit.Assert.*;
import org.junit.Test;

import java.io.FileNotFoundException;

public class UserTest {

    @Test
    public void LoginFail() throws FileNotFoundException {
        //try username and password not in dat file
        assertFalse(User.login("gkelvin","Paris123"));
    }

    @Test
    public void LoginSucess() throws FileNotFoundException {
        //try username and password in dat file
        assertTrue(User.login("jsmith","piglet123"));
    }
}