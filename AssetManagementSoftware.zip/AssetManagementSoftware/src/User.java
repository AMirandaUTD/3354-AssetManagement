import java.io.*;
import java.util.Scanner;

public class User {

    private String username = "";
    private String password = "";
    private String email = "";
    private String accessLevel = "";

    public User(String username, String password, String email, String accessLevel)
    {
        this.username = username;
        this.password = password;
        this.email = email;
        this.accessLevel = accessLevel;
    }

    public static boolean login(String inputUsername, String inputPassword) throws FileNotFoundException {
        boolean loginStatus = false;

        File users = new File("Users.dat");
        Scanner readUsers = new Scanner(users);
        while (readUsers.hasNextLine()) {
            //read in line from file and split into components: username, password, email, access level
            String user = readUsers.nextLine();
            String[] componentArray = user.split(", ");

            if (componentArray[0].equals(inputUsername)) {
                if (componentArray[1].equals(inputPassword)) {
                    loginStatus = true;
                    break;
                }
            }
        }
        readUsers.close();

        return loginStatus;
    }
}
